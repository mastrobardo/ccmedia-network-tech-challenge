export interface Item {
    id: number;
    name: string;
    ibu: number;
    abv: number;
    description: string;
    image_url: string;
}
